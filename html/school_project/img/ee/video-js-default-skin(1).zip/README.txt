A Pen created at CodePen.io. You can find this one at https://codepen.io/heff/pen/EarCt.

 This is the base skin of Video.js that can be modified to make custom skins.

The great thing about Video.js skins is they work in both HTML5 video AND Flash!